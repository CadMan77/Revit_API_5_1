﻿//Создайте приложение с несколькими кнопками: 
//    1 кнопка по нажатию должна выводить окно с количеством труб, 
//    2 кнопка – окно с объёмом всех стен, 
//    3 кнопка – окно с количеством дверей.

using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Revit_API_5_1
{
    [Transaction(TransactionMode.Manual)]

    public class Main : IExternalApplication
    {
        public Result OnShutdown(UIControlledApplication application)
        {
            return Result.Succeeded;
        }

        public Result OnStartup(UIControlledApplication application)
        {
            string utilName = "Revit_API_5_1";
            string utilFolderPath = @"C:\ProgramData\RevitAPITraining\";
            string assembly = Path.Combine(utilFolderPath, $"{utilName}.dll");

            //string className = $"{utilName}.MainViewViewModel";
            string className = $"{utilName}.Main";

            string tabName = "RevitApiTraining";
            application.CreateRibbonTab(tabName);
            string panelName = "Статистика";
            RibbonPanel myPanel = application.CreateRibbonPanel(tabName, panelName);

            PushButtonData pbdPipeQty = new PushButtonData("buttonPipeQty", "Трубы (кол-во)", assembly, className);
            PushButtonData pbdTotWallVolume = new PushButtonData("buttonTotWallVolume", "Стены (объем)", assembly, className);
            PushButtonData pbdDoorQty = new PushButtonData("buttonDoorQty", "Двери (кол-во)", assembly, className);

            //myPanel.AddItem(buttonPipeQty);
            myPanel.AddStackedItems(pbdPipeQty, pbdTotWallVolume, pbdDoorQty);

            return Result.Succeeded;
        }
    }
}